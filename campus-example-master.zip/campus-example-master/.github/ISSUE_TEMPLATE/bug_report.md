---
name: 报告bug
about: 创建一个报告来帮助我们改进
title: "[bug]: "
labels: bug
---

<!--请按照模板填写，否则此issue将可能被关闭-->

## 版本情况

Campus版本： X.X.X（请确保最新尝试是否还有问题）

## 问题描述

<!--xxxx-->

1. 复现代码

```java
Console.log("报错了");
```

2. 测试涉及到的文件

## 问题截图（如有）
<!--![](xxx.jpg)-->

## 补充说明（可选）
<!--xxxx-->